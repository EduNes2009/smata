
package empleado;

/**
 *
 * @author alumno
 */
public class Oficial  extends Operario{

    public Oficial() {
    }

    public Oficial(String nombre) {
        super(nombre);
    }

    
    public static String NOficial(){
        String nombre = "Luis" + " Operario" + " Oficial";
        return nombre;
    }
    
    @Override
    public String toString() {
        return "Empleado " + NOficial();
    }
    
    
    

}
