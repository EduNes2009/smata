package empleado;

public class Empleado {
    
    //Atributo
    private String nombre;

    
    //Constructores
    public Empleado() {
    }

    public Empleado(String nombre) {
        this.setNombre(nombre);
    }

    //Getter y Setter
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public static String NEmpleado(){
        String nombre = "Rafael";
        return nombre;
    }

    @Override
    public String toString() {
        return "Empleado " + NEmpleado();
    }
    
    
        

}
