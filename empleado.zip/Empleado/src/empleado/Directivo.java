package empleado;


public final class Directivo extends Empleado{

    public Directivo() {
    }

    public Directivo(String nombre) {
        super(nombre);
    }
    
    public static String NDirectivo(){
        String nombre = "Mario" + " Directivo";
        return nombre;
    }

    @Override
    public String toString() {
        return "Empleado " + NDirectivo();
    }

    
    
    
}


