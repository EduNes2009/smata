
package empleado;


public class Operario extends Empleado{

    public Operario() {
    }

    public Operario(String nombre) {
        super(nombre);
    }
    
    public static String NOperario(){
        String nombre = "Alfonso" + " Operario";
        return nombre;
    }

    @Override
    public String toString() {
        return "Empleado " + NOperario();
    }
    
    
    

}
