
package empleado;

/**
 *
 * @author alumno
 */
public class Test {
    
    public static void main(String[] args) {
        
        Empleado E1 = new Empleado();
        Directivo D1 = new Directivo();
        Operario OP1 = new Operario();
        Oficial OF1 = new Oficial();
        Tecnico T1 = new Tecnico();
        
        
        System.out.println(E1);
        System.out.println(D1);
        System.out.println(OP1);
        System.out.println(OF1);
        System.out.println(T1);
        
        
    }
    
    
    

}
