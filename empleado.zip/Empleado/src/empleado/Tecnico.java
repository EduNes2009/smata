
package empleado;

/**
 *
 * @author alumno
 */
public final class Tecnico extends Operario{

    public Tecnico() {
    }

    public Tecnico(String nombre) {
        super(nombre);
    }
    
    public static String NTecnico(){
        String nombre = "Pablo" + " Operario" + " Tecnico";
        return nombre;
    }

    @Override
    public String toString() {
        return "Empleado " + NTecnico();
    }
 
}
